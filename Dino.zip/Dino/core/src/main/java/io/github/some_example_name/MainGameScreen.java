package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.compression.lzma.Base;

import javax.swing.plaf.nimbus.State;

import actores.ActorJugador;
import actores.ActorRoca;

public class MainGameScreen extends BaseScreen {

    private Stage stage;
    private ActorJugador jugador;
    private ActorRoca roca;
    private Texture textureJugador, textureJugadorRoca;
    private boolean detenerRoca= false;
    public MainGameScreen(Main Game) {
        super(Game);
        textureJugador = new Texture("dinosaour.png");
        textureJugadorRoca = new Texture("roca.png");

    }

    @Override
    public void show() {
        stage = new Stage();
        stage.setDebugAll(true);

        jugador = new ActorJugador(textureJugador);
        roca = new ActorRoca(textureJugadorRoca);

        stage.addActor(jugador);
        stage.addActor(roca);

        jugador.setPosition(20,100);
        roca.setPosition(400,100);

    }

    @Override
    public void hide() {
        stage.dispose();
    }

    @Override
    public void dispose() {
        textureJugador.dispose();
        textureJugadorRoca.dispose();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act(); //se encarga de actualizar los elemenos del escenario
        comprobarColisiones();

        stage.draw(); //se encarga de dibujar
    }
    private void comprobarColisiones(){
        if (jugador.isAlive()&& (
            jugador.getX() + jugador.getWidth() > roca.getX())) {
            System.out.println("Colision detectada");
            jugador.setAlive(false);
            roca.detenerRoca();
        }
    }
}
