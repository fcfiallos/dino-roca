package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Box2D;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;

public class Box2DScreen extends BaseScreen {

    private World world;
    private Box2DDebugRenderer renderer;
    private OrthographicCamera camera;
    private Body jugadorBody, sueloBody, rocaBody;
    private Fixture jugadorFixture, sueloFixture, rocaFixture;
    private Boolean colisionDetectada = false;

    private boolean jugadorDetenido = false;
    private boolean debeDetenerJugador = false;


    public Box2DScreen(Main Game) {
        super(Game);
    }

    @Override
    public void show() {
        //esta de aqui es para la gravedad para donde bajara
        world = new World(new Vector2(0, -10), true);
        renderer = new Box2DDebugRenderer();
        camera = new OrthographicCamera(32, 18);

        world.setContactListener(new ContactListener() {
            @Override
            public void beginContact(Contact contact) {
                Fixture fixtureA = contact.getFixtureA();
                Fixture fixtureB = contact.getFixtureB();
                boolean jugadorConRoca =
                    (fixtureA == jugadorFixture && fixtureB == rocaFixture) ||
                        (fixtureB == jugadorFixture && fixtureA == rocaFixture);

                // Solo marcamos, no modificamos cuerpos aquí
                if (jugadorConRoca && !jugadorDetenido) {
                    colisionDetectada = true;
                    debeDetenerJugador = true; // <- posponemos el cambio
                }
            }

            @Override
            public void endContact(Contact contact) {

            }

            @Override
            public void preSolve(Contact contact, Manifold oldManifold) {

            }

            @Override
            public void postSolve(Contact contact, ContactImpulse impulse) {

            }
        });
        BodyDef jugadorDef = createDef();
        jugadorBody = world.createBody(jugadorDef);

        PolygonShape jugadorShape = new PolygonShape();
        jugadorShape.setAsBox(1, 1);
        jugadorFixture = jugadorBody.createFixture(jugadorShape, 1);
        jugadorShape.dispose();

        BodyDef sueloDef = createdDef();
        sueloBody = world.createBody(sueloDef);

        // forma del suelo
        PolygonShape sueloShape = new PolygonShape();
        // ancho: 500, alto: 1 (Box2D mide desde el centro, así que 250 de cada lado)
        sueloShape.setAsBox(500, 1);
        sueloFixture = sueloBody.createFixture(sueloShape, 1);
        sueloShape.dispose();


        BodyDef obstaculoDef = obstcauloDef(5);
        rocaBody = world.createBody(obstaculoDef);
        Vector2[] vertices = new Vector2[3];
        vertices[0] = new Vector2(-0.5f, -0.5f);
        vertices[1] = new Vector2(0.5f, -0.5f);
        vertices[2] = new Vector2(0f, 0.5f);

        PolygonShape obstaculoShape = new PolygonShape();
        obstaculoShape.set(vertices);

        rocaFixture = rocaBody.createFixture(obstaculoShape, 1);
        obstaculoShape.dispose();
    }

    @Override
    public void dispose() {
        world.destroyBody(jugadorBody);
        world.dispose();
        renderer.dispose();


    }

    @Override
    public void render(float delta) {
        //  Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        //saltos
        /*if (Gdx.input.justTouched()) {
            saltar();
        }
        if(!colisionDetectada){
            System.out.println("Colision deetectada");
        }*/
        // Ejecutamos las acciones pendientes después de step
        if (debeDetenerJugador) {
            detenerJugador(); // ahora sí es seguro
            debeDetenerJugador = false;
        }

        // Solo saltar si no hay colisión
        if (!colisionDetectada && Gdx.input.justTouched()) {
            saltar();
        }

        // Solo moverse si no hay colisión
        if (!colisionDetectada) {
            jugadorBody.setLinearVelocity(2, jugadorBody.getLinearVelocity().y);
        }

        //creamos el mundo
        world.step(delta, 6, 2);
        camera.update();
        this.renderer.render(world, camera.combined);

    }

    private BodyDef createDef() {
        BodyDef def = new BodyDef();
        def.position.set(-5, 6);
        //tipo del cuerpo
        def.type = BodyDef.BodyType.DynamicBody;
        return def;
    }

    private BodyDef createdDef() {
        BodyDef def = new BodyDef();
        def.position.set(0, -7);
        //tipo del cuerpo
        def.type = BodyDef.BodyType.StaticBody;
        return def;
    }

    private BodyDef obstcauloDef(float x) {
        BodyDef def = new BodyDef();
        def.position.set(x, -5.5f);
        //tipo del cuerpo
        //por default es estatico
        return def;
    }

    private void saltar() {
        Vector2 position = jugadorBody.getPosition();
        //jugadorBody.applyLinearImpulse(0, 15, position.x, position.y, true);
        jugadorBody.applyAngularImpulse(30,true);

    }
    private void detenerJugador() {
        jugadorDetenido = true;
        jugadorBody.setLinearVelocity(0, 0);
        jugadorBody.setAngularVelocity(0);
        jugadorBody.setAwake(false); // duerme el cuerpo
        jugadorBody.setType(BodyDef.BodyType.StaticBody); // <- lo hace completamente inmóvil
        System.out.println("Colisión detectada: jugador detenido definitivamente");
    }
}

