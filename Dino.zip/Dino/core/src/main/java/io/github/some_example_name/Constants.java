package io.github.some_example_name;

public class Constants {
    public static final float PIXELS_IN_METERS=90;
}
