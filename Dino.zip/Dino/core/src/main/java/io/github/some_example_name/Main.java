package io.github.some_example_name;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {
    private AssetManager manager;

    public  AssetManager getManager() {
        return manager;
    }

    @Override
    public void create() {
        manager = new AssetManager();
        manager.load("dinosaour.png", Texture.class);
        // Esperamos hasta que termine de cargar (bloqueante pero simple)
        manager.load("roca.png", Texture.class); // 👈 NUEVA LÍNEA: cargamos la textura de la roca
        manager.load("suelo.jpg", Texture.class); // 👈 NUEVO
        manager.finishLoading();
        setScreen(new GameScreen(this));

    }
}
