package actores;

import static io.github.some_example_name.Constants.PIXELS_IN_METERS;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class ObstaculoEntity extends Actor {
    private Texture textureO;
    private World worldO;
    private Body bodyO;
    private Fixture fixtureO;

    public ObstaculoEntity(Texture textureO, World worldO, Vector2 positionO) {
        this.textureO = textureO;
        this.worldO = worldO;

        // Definición del cuerpo físico (estático)
        BodyDef obstaculoDef = new BodyDef();
        obstaculoDef.position.set(positionO);
        obstaculoDef.type = BodyDef.BodyType.StaticBody;
        bodyO = worldO.createBody(obstaculoDef);

        // Definir la forma del obstáculo
        PolygonShape obstaculoShape = new PolygonShape();
        obstaculoShape.setAsBox(1, 1); // tamaño físico en metros
        fixtureO = bodyO.createFixture(obstaculoShape, 1);
        obstaculoShape.dispose();

        // Tamaño visual en píxeles
        setSize(PIXELS_IN_METERS, PIXELS_IN_METERS);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        setPosition(bodyO.getPosition().x * PIXELS_IN_METERS, bodyO.getPosition().y * PIXELS_IN_METERS);
        batch.draw(textureO, getX(), getY(), getWidth(), getHeight());
    }

    public void detach() {
        bodyO.destroyFixture(fixtureO);
        worldO.destroyBody(bodyO);
    }
}
