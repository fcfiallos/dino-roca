package actores;

import static io.github.some_example_name.Constants.PIXELS_IN_METERS;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class SueloEntity extends Actor {
    private Texture textureS;
    private World worldS;
    private Body bodyS;
    private Fixture fixtureS;

    public SueloEntity(Texture textureS, World worldS, Vector2 positionS) {
        this.textureS = textureS;
        this.worldS = worldS;

        // Definición del cuerpo físico (estático)
        BodyDef sueloDef = new BodyDef();
        sueloDef.position.set(positionS);
        sueloDef.type = BodyDef.BodyType.StaticBody;
        bodyS = worldS.createBody(sueloDef);

        // Definir la forma (suelo ancho y delgado)
        PolygonShape sueloShape = new PolygonShape();
        sueloShape.setAsBox(10, 0.5f); // ancho 10m, alto 0.5m
        fixtureS = bodyS.createFixture(sueloShape, 1);
        sueloShape.dispose();

        // Tamaño visual en píxeles
        setSize(20 * PIXELS_IN_METERS, PIXELS_IN_METERS);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        setPosition(
            (bodyS.getPosition().x - 10) * PIXELS_IN_METERS, // -10 para centrar el ancho
            (bodyS.getPosition().y - 0.5f) * PIXELS_IN_METERS
        );
        batch.draw(textureS, getX(), getY(), getWidth(), getHeight());
    }

    public void detach() {
        bodyS.destroyFixture(fixtureS);
        worldS.destroyBody(bodyS);
    }
}
