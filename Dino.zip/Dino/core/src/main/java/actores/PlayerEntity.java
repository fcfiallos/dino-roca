package actores;

import static io.github.some_example_name.Constants.PIXELS_IN_METERS;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;

import io.github.some_example_name.Constants;

public class PlayerEntity extends Actor {
    private Texture textureP;
    private World worldP;
    private Body bodyP;
    private Fixture fixtureP;

    public PlayerEntity(Texture textureP, World worldP, Vector2 positionP) {
        this.textureP = textureP;
        this.worldP = worldP;
        BodyDef jugadorDef = new BodyDef();
        jugadorDef.position.set(positionP);
        jugadorDef.type = BodyDef.BodyType.DynamicBody;
        bodyP = worldP.createBody(jugadorDef);

        PolygonShape jugadorShape = new PolygonShape();
        jugadorShape.setAsBox(1, 1);
        fixtureP = bodyP.createFixture(jugadorShape, 1);
        jugadorShape.dispose();

        setSize(PIXELS_IN_METERS, PIXELS_IN_METERS);

    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        setPosition(bodyP.getPosition().x * PIXELS_IN_METERS, bodyP.getPosition().y * PIXELS_IN_METERS);
        batch.draw(textureP, getX(), getY(), getWidth(), getHeight());
    }

    public void detach() {
        bodyP.destroyFixture(fixtureP);

        worldP.destroyBody(bodyP);
    }
}
