package actores;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class ActorRoca extends Actor {
    //los actores son os que se agregan al stage

    private Texture tRoca;
    private boolean rocaDetenida= false;

    public ActorRoca(Texture tJugador) {
        this.tRoca = tJugador;
        setSize(tRoca.getWidth(), tRoca.getHeight());
    }

    @Override
    public void act(float delta) {
        if (!rocaDetenida) {
            setX(getX() - 250 * delta);  // Mueve la roca hacia la izquierda
        }
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(tRoca, getX(), getY());
    }

    public void detenerRoca() {
        rocaDetenida = true;
    }
}
