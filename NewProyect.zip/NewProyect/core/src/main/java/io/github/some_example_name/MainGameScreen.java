package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;

import io.github.some_example_name.actores.ActorJugador;
import io.github.some_example_name.actores.ActorRoca;

public class MainGameScreen extends BaseScreen {
    private Stage stage;
    private ActorJugador jugador;
    private ActorRoca roca;
    private Texture textureJugador, textureRoca;

    public MainGameScreen(Main game) {
        super(game);
        textureJugador = new Texture("dino.png");
        textureRoca = new Texture("roca.png");
    }

    @Override
    public void show() {
        stage = new Stage();

        stage.setDebugAll(true);
        jugador = new ActorJugador(textureJugador);
        roca = new ActorRoca(textureRoca);
        stage.addActor(jugador);
        stage.addActor(roca);

        jugador.setPosition(20, 100);
        roca.setPosition(500, 100);

    }

    @Override
    public void hide() {
        stage.dispose();
    }

    @Override
    public void dispose() {
        textureJugador.dispose();
        textureRoca.dispose();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act();
        comprobarColisiones();
        stage.draw();
    }

    private void comprobarColisiones() {
        if (jugador.isAlive() && (jugador.getX() + jugador.getWidth() > roca.getX())) {
            System.out.println("Colision detectada");
            jugador.setAlive(false);
            roca.stopMoving(false);  // Detenemos la roca
        }
    }
}
